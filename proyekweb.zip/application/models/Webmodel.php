<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Webmodel extends CI_Model {


      public function loginmodel($email,$password){

              $this->db->where('email_staff', $email);
              $this->db->where('password', $password);

              $q = $this->db->get('pengguna');
              return $q->result();
      }

	
	function insertmodel(){
		$idstaff=$this->input->post('idstaff');
		$namastaff=$this->input->post('namastaff');
		$emailstaff=$this->input->post('emailstaff');
		$passwordstaff=$this->input->post('passwordstaff');
		$kontakstaff=$this->input->post('kontakstaff');

		$data=array(
			'id_staff'=> $idstaff,
			'nama_staff'=> $namastaff,
			'email_staff'=> $emailstaff,
			'password'=> $passwordstaff,
			'kontak_staff'=> $kontakstaff

			);

		$this->db->insert('pengguna',$data);

	}

	function getdatapengguna(){
		$query=$this->db->get('pengguna');
		return $query->result();
	}
}
?>
